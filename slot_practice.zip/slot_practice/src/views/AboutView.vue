<template>
    <base-card>
        <div class="container">
          <div class="add-item">
              <button id="add" @click="showPopup">Add +</button>
          </div>
          <div class="search">
                  <input type="text" placeholder="Search...">
                  <button id="search">Search</button>
          </div>
          <about-list @delete-item="deleteItem" @edit-item="editItem" />  
        </div>
          <form-create v-if="isPopup" :update_item="old_items"  @close-popup= "closePopup" @create-item="createItem"/>  
    </base-card>
</template>

<script>
import aboutlist from "@/components/about/AboutList.vue";
import formcreate from "@/components/about/FormCreateItem.vue";
export default {
  name: 'AboutView',
  components: {
    'about-list': aboutlist,
    'form-create': formcreate
  },
  data(){
    return{
        items: [
                {
                    id: 1,
                    name: "Book",
                    description: "To use the Font Awesome icons, add the following line inside the"
                },
                {
                    id: 2,
                    name: "Pen",
                    description: "To use the Font Awesome icons, add the following line inside the"
                },
                {
                    id: 3,
                    name: "Ruler",
                    description: "To use the Font Awesome icons, add the following line inside the"
                }
            ],
        isPopup: false,
        old_items: {
          title:  "Create New Item",
          name: "Title...",
          description: "Description..."
        }
    }
  },
  provide(){
    return {
      items: this.items
    }
  },
  methods:{
    showPopup(){
      this.isPopup = true
    },
    closePopup(){
      this.isPopup = false;
      this.old_items.title = "Create New Item"
    },
    createItem(title, description){
      this.items.push({name: title, description: description});
      this.closePopup()
    },
    deleteItem(index){
      for (let i in this.items){
        if (i == index){
          this.items.splice(i, 1);
        }
      }
    },
  editItem(index,name, description){
    this.isPopup = true;
    this.old_items.title = "Update Item";
    this.old_items.name = name;
    this.old_items.description = description;
    console.log(index,name, description);
  }
    
  },
}
</script>



<style>
    .container{
        width: 60%;
        margin: 50px auto;
    }
    .container button{
        border: none;
        color: #fff;
        cursor: pointer;
        border-radius: 4px;
    }
    .add-item{
      display: flex;
      justify-content: end;
      margin: 10px 0;
      
    }
    #add{
        width: 20%;
        background: rgb(2, 89, 251);
        padding: 10px;
        text-align: center;
        font-size: 16px;
    }
    #search{
        float: right;
        width: 20%;
        background: #fbb902;
        padding: 10px;
        text-align: center;
        font-size: 16px;
    }
    .container button:focus, .container .search input:focus{
      outline: 2px solid #02b0fb;
    }
    .container .search input{
      font-size: 16px;
      width: 40%;
      padding: 12px 12px;
      outline: none;
      border: 1px solid #aaa;
      border-radius: 4px;
      transition: .6s ease-in-out;
    }
    .container .search input:focus{
      width: 80%;
      transition: .6s ease-in-out;
    }
</style>