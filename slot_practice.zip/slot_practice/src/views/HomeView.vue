<template>
    <base-card>
        <home-list/>  
    </base-card>
</template>

<script>
import homelist from "@/components/home/HomeList.vue";
export default {
  name: 'HomeView',
  components: {
    'home-list': homelist
  },
  data(){
    return{
      products: [
          {
            name: "Boy",
            image: "https://letsenhance.io/static/334225cab5be263aad8e3894809594ce/75c5a/MainAfter.jpg",
            description: "To use the Font Awesome icons, add the following line inside the"
          },
          {
            name: "Bird",
            image: "https://assets-global.website-files.com/6005fac27a49a9cd477afb63/60576840e7d265198541a372_bavassano_homepage_gp.jpg",
            description: "To use the Font Awesome icons, add the following line inside the"
          },
          {
            name: "Tree",
            image: "https://static.addtoany.com/images/dracaena-cinnabari.jpg",
            description: "To use the Font Awesome icons, add the following line inside the"
          }
      ]
    }
  },
  provide(){
    return {
      products: this.products
    }
  }
}
</script>
