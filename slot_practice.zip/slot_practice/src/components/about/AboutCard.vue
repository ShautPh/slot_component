<template>
        <div class="card">
                <div class="text-group">
                        <h1>{{item.name}}</h1>
                        <p>{{item.description}}</p>
                </div>
                <div class="btn-group">
                        <button id="btn___delete" @click="deleteItem(index)">Delete</button>
                        <button id="btn___edit" @click="editItem(index, item.name,item.description)">Edit</button>
                </div>
        </div>

</template>

<script>
    export default {
        props: {
            item: Object,
            index: Number
        },
        emits: ["delete-item", "edit-item"],
        methods: {
            deleteItem(index){
                return this.$emit('delete-item', index)
            },
            editItem(index,name, description){
                // console.log(index,name, description);
                return this.$emit('edit-item', index,name, description);
            }
        }
    }
</script>

<style scoped>
    .card{
        padding: 20px;
        border-radius: 6px;
        margin: 10px 0;
        display: flex;
        box-shadow: 2px 2px 8px 1px #cccc;
        justify-content: space-between;
        align-items: center;
        background: #fff;
    }
    .card h1{
        color: #0505e1fc;
        font-size: 26px;
    }
    button{
        border: none;
        color: #fff;
        cursor: pointer;
        border-radius: 4px;
        padding: 10px 16px  ;
        margin: 0 8px;
    }
    #btn___delete{
        background: #ff0000;
    }
    #btn___edit{
        background: #fbb902;
    }
</style>