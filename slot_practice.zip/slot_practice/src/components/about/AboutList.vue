<template>
    <about-card v-for="(item,index) of items" :key="item" :index="index" :item="item" @delete-item="deleteItem" @edit-item="editItem" />
</template>

<script>
import aboutcard from "./AboutCard.vue"
export default {
    components: {
        'about-card': aboutcard
    },
    inject: ['items'],
    emits: ["delete-item",'edit-item'],
    methods: {
        deleteItem(index){
            return this.$emit('delete-item', index)
        },
        editItem(index,name, description){
            return this.$emit('edit-item', index,name, description);
        }
    }
}
</script>