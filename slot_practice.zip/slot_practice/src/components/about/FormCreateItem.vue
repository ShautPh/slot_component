<template>
<div class="pop-up">
    <form @submit.prevent="createNewItem">
        <div class="card">
            <div class="card-header">
                <h2>{{update_item.title}}</h2>
                <i class="fa fa-close" style="font-size:24px" @click="$emit('close-popup')"></i>
            </div>
            <div class="card-content">
                <div class="input-group">
                    <label for="">Title</label>
                    <input type="text" required :placeholder="update_item.name" v-model="title">
                </div>
                <div class="input-group">
                    <label for="">Description</label><br>
                    <textarea rows="10" required   :placeholder="update_item.description" v-model="description">
                        
                    </textarea>
                </div>
                <button type="submit">Create Item</button>
            </div>
        </div>
    </form>
</div>
</template>

<script>
export default {
    props: {
        update_item: Object
    },
    
    emits: ['create-item'],
    data(){
        return {
            title: "",
            description: ""
        }
    },
    methods: {
        createNewItem(){
            return  this.$emit('create-item',  this.title, this.description)
        }
    }
}
</script>
<style scoped>  
    .pop-up{
        position: absolute;
        width: 100%;
        height: 100%;
        background: rgb(15,15,15,0.6);
        top: 0;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .card{
        width: 460px;
        border-radius: 8px;
        box-shadow: 2px 2px 8px 1px #aaa;
        background: #fff;
        min-height: 260px;
        height: auto;
    }
    .card .card-header{
        padding: 8px 10px;
        background: #031cff;
        color: #fff;
        display: flex;
        justify-content: space-between;
    }
    .card .card-header i:hover{
        cursor: pointer;
        color: #ff0000;
        transition: .4s;
    }
    .card-content{
        padding: 20px;
        /* margin-bottom: 20px; */
    }
    .card-content .input-group{
        margin: 12px 0
    }
    label{

        margin-bottom: 6px;
    }
    .card-content input{
        padding: 12px 12px;
        border: 1px solid #aaa;
        outline: none;
        width: 100%;
        border-radius: 4px;
        font-size: 16px;
    }
    textarea{
        resize: none;
        width: 100%;
        padding: 12px 12px;
        border: 1px solid #aaa;
        outline: none;
        border-radius: 4px;
        font-size: 18px;
        height: 120px;
          font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
    }
    .card-content input:focus,button:focus, textarea:focus  {
        outline: 2px solid #02b0fb;
    }

    button{
        border: none;
        color: #fff;
        cursor: pointer;
        border-radius: 4px;
        background: #031cff;
        width: 100%;
        padding: 10px ;
        margin-top: 16px;
        font-size: 16px;
    }
</style>