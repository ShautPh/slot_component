<template>
    <div class="slot">
        <slot />
    </div>
</template>