<template>
    <home-card v-for="product in products" :key="product" :product="product"/>
</template>

<script>
import homecard from "./HomeCard.vue"
export default {
    components: {
        'home-card': homecard
    },
    inject: ['products'],
}
</script>