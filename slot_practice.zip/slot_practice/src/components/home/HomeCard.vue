<template>
        <div class="card">
            <div class="name">
                <h1>{{product.name}}</h1>
            </div>
            <div class="image">
                <img :src="product.image" alt="">
            </div>
            <div class="description">{{product.description}}</div>
        </div>
</template>

<script>
    export default {
        props: {
            product: Object
        }
    }
</script>
<style scoped>
    .card{
        width: 80%;
        display: flex;
        align-items: center;
        position: relative;
        margin: 20px auto;
        background: #fff;
        box-shadow: 2px 2px 8px 1px #ccc;
        padding: 10px;
        border-radius: 8px;
    }
    .card .name{
        width: 20%;
    }
    .card .image{
        width: 30%;
        padding: 10px;
    }
    .card img{
        width: 100%;
    }
    .card .description {
        width: 50%;
        text-align: right;
    }
</style>