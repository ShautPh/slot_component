import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import baseCard from "./components/BaseCard.vue";
const app = createApp(App);
app.component('base-card', baseCard);
app.use(router).mount('#app')
